INSTRUCCIONES DE USO - Proyecto Medigray adaptado a Oracle

1. ABRIR SQL DEVELOPER Y EJECUTAR:
   sql/medigray_oracle_setup.sql con usuario SYSTEM (crea el usuario, tablas y un ejemplo).

2. CONFIGURAR Y EJECUTAR EL SERVIDOR:
   - Tener Node.js instalado.
   - En terminal:
       cd JS
       npm install express oracledb cors body-parser
       node server.js
   - El servidor quedará en http://localhost:3000

3. ENVIAR DATOS DE PRUEBA:
   Puedes hacer un POST a http://localhost:3000/contacto con los siguientes datos:
   {
     "nombre": "Tu Nombre",
     "correo": "tu@correo.com",
     "asunto": "Asunto X",
     "mensaje": "Tu mensaje aquí"
   }

4. VERIFICAR EN ORACLE:
   En SQL Developer, conecta como MEDIGRAY y ejecuta:
     SELECT * FROM contactos;

¡Listo! Ya tienes el sistema funcionando conectado con Oracle.
