
CREATE USER medigray IDENTIFIED BY "123"
DEFAULT TABLESPACE USERS
TEMPORARY TABLESPACE TEMP
QUOTA UNLIMITED ON USERS;

GRANT CREATE SESSION TO medigray;
GRANT CREATE TABLE, CREATE SEQUENCE, CREATE TRIGGER, CREATE VIEW TO medigray;

ALTER SESSION SET CURRENT_SCHEMA = medigray;

CREATE TABLE contactos (
    id        NUMBER(10) GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre    VARCHAR2(100) NOT NULL,
    correo    VARCHAR2(255) NOT NULL,
    asunto    VARCHAR2(255),
    mensaje   CLOB
);

INSERT INTO contactos (nombre, correo, asunto, mensaje)
VALUES ('Ejemplo', 'ejemplo@correo.com', 'Consulta', 'Este es un mensaje de prueba');
