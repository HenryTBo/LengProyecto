const express = require('express');
const oracledb = require('oracledb');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, '../html')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../html/index.html'));
});

async function getConnection() {
  return await oracledb.getConnection({
    user: 'medigray',
    password: '123',
    connectString: 'localhost/XEPDB1'
  });
}

app.get('/test-conexion', async (req, res) => {
  try {
    const conn = await getConnection();
    const result = await conn.execute('SELECT SYSDATE FROM DUAL');
    await conn.close();
    res.json({
      status: 'success',
      message: 'Conexión a Oracle exitosa',
      timestamp: result.rows[0][0]
    });
  } catch (err) {
    res.status(500).json({
      status: 'error',
      message: 'Error de conexión a Oracle',
      error: err.message
    });
  }
});

app.get('/contactos', async (req, res) => {
  try {
    const conn = await getConnection();
    const result = await conn.execute('SELECT * FROM contactos ORDER BY ID DESC');
    await conn.close();
    res.json({
      status: 'success',
      data: result.rows,
      columns: result.metaData.map(col => col.name)
    });
  } catch (err) {
    res.status(500).json({
      status: 'error',
      message: 'Error al consultar contactos',
      error: err.message
    });
  }
});

app.post('/contacto', async (req, res) => {
  const { nombre, correo, asunto, mensaje } = req.body;
  try {
    const connection = await getConnection();
    await connection.execute(
      `INSERT INTO contactos (nombre, correo, asunto, mensaje, fecha)
       VALUES (:nombre, :correo, :asunto, :mensaje, SYSDATE)`,
      { nombre, correo, asunto, mensaje },
      { autoCommit: true }
    );
    await connection.close();
    res.status(200).json({ 
      status: 'success',
      message: 'Formulario enviado correctamente. Gracias.' 
    });
  } catch (err) {
    console.error('Error al insertar en Oracle:', err);
    res.status(500).json({ 
      status: 'error',
      message: 'Error al guardar el mensaje',
      error: err.message 
    });
  }
});

app.post('/postulacion', async (req, res) => {
  const {
    nombreCompleto,
    email,
    telefono,
    cedula,
    edad,
    direccion,
    puestoInteres,
    experiencia,
    nivelEducativo,
    disponibilidad,
    motivacion
  } = req.body;

  console.log('📋 Datos de postulación recibidos:', req.body);

  try {
    const connection = await getConnection();
    await connection.execute(
      `INSERT INTO postulaciones 
        (nombre_completo, correo, telefono, cedula, edad, direccion, puesto_interes, experiencia, nivel_educativo, disponibilidad, motivacion, fecha)
       VALUES 
        (:nombre_completo, :correo, :telefono, :cedula, :edad, :direccion, :puesto_interes, :experiencia, :nivel_educativo, :disponibilidad, :motivacion, SYSDATE)`,
      {
        nombre_completo: nombreCompleto,
        correo: email,
        telefono,
        cedula,
        edad: parseInt(edad),
        direccion,
        puesto_interes: puestoInteres,
        experiencia,
        nivel_educativo: nivelEducativo,
        disponibilidad,
        motivacion
      },
      { autoCommit: true }
    );
    await connection.close();
    
    console.log('✅ Postulación guardada exitosamente');
    res.status(200).json({ 
      status: 'success',
      message: 'Postulación enviada con éxito. Nos pondremos en contacto pronto.' 
    });
  } catch (err) {
    console.error('❌ Error al guardar postulación:', err);
    res.status(500).json({ 
      status: 'error',
      message: 'Error al guardar la postulación',
      error: err.message 
    });
  }
});

app.get('/postulaciones', async (req, res) => {
  try {
    const conn = await getConnection();
    const result = await conn.execute('SELECT * FROM postulaciones ORDER BY fecha DESC');
    await conn.close();
    res.json({
      status: 'success',
      data: result.rows,
      columns: result.metaData.map(col => col.name)
    });
  } catch (err) {
    res.status(500).json({
      status: 'error',
      message: 'Error al consultar postulaciones',
      error: err.message
    });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Servidor escuchando en http://localhost:${PORT}`);
});